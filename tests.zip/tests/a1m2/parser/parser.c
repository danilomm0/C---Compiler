/*
 * File: parser.c
 * Author: Saumya Debray
 * Purpose: Recursive-descent parser for C-- for the G0 subset of the 
 *    CSC 453 project
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "scanner.h"

extern int get_token();    /* the scanner */
extern char* lexeme;
extern int linenum;

/*******************************************************************************
 *                                                                             *
 *                              TOKEN-MANAGEMENT                               *
 *                                                                             *
 *******************************************************************************/

/*
 * token_name is an array of strings that gives, for each token value,
 * a string indicating the type of token.
 */
char* token_name[] = {
  "UNDEF",
  "ID",
  "INTCON",
  "LPAREN",
  "RPAREN",
  "LBRACE",
  "RBRACE",
  "COMMA",
  "SEMI",
  "kwINT",
  "kwIF",
  "kwELSE",
  "kwWHILE",
  "kwRETURN",
  "opASSG",
  "opADD",
  "opSUB",
  "opMUL",
  "opDIV",
  "opEQ",
  "opNE",
  "opGT",
  "opGE",
  "opLT",
  "opLE",
  "opAND",
  "opOR",
  "opNOT",
};

Token curr_tok;

#define ERRMSG_LOCN(tok, lexeme, locn) { \
      char* tok_name = (tok == EOF ? "EOF" : token_name[tok]); \
      fprintf(stderr, "ERROR [%s]: unexpected token %s [lexeme = %s]\n", \
	      locn, tok_name, lexeme); \
      error_code = 1; \
  }

#define ERRMSG(tok, lexeme)  ERRMSG_LOCN(tok, lexeme, __func__)

#define MATCH_LOCN(expected, locn)  {			\
    if (curr_tok == expected) {			\
      curr_tok = get_token(); /* consume the current token */	\
    } \
    else ERRMSG_LOCN(curr_tok, lexeme, locn);		\
  }

#define MATCH(expected)  MATCH_LOCN(expected, __func__)

/*
 * The macro SET() takes the integer value N of a token and returns a bit-vector
 * with position N+1 set to 1 and the remaining positions set to 0; as a special
 * case, EOF is at position 0.
 */
#define SET(tok)  (1 << ((tok)+1))

#define CHK_TOK_IN_FOLLOW(tok) { \
	if (!tok_in_Follow(curr_tok, __func__)) { \
   	    ERRMSG(curr_tok, lexeme); \
	} \
  }

/*******************************************************************************
 *                                                                             *
 *                                  PROTOTYPES                                 *
 *                                                                             *
 *******************************************************************************/

int type();
int opt_formals();
int opt_var_decls();
int opt_stmt_list();
int stmt();
int opt_expr_list();
int fn_call();
int func_defn();
int prog();
int parse();
int tok_in_First(int tok, const char *nonterm);
int tok_in_Follow(int tok, const char *nonterm);

/*******************************************************************************
 *                                                                             *
 *                               PARSING FUNCTIONS                             *
 *                                                                             *
 *******************************************************************************/

int error_code = 0;

int prog() {
  while (tok_in_First(curr_tok, "type")) {
    func_defn();
  }

  CHK_TOK_IN_FOLLOW(curr_tok);
  return 0;
}

int func_defn() {
  type();
  MATCH(ID);
  MATCH(LPAREN);
  opt_formals();
  MATCH(RPAREN);
  MATCH(LBRACE);
  opt_var_decls();
  opt_stmt_list();
  MATCH(RBRACE);

  //CHK_TOK_IN_FOLLOW(curr_tok);
  return 0;
}

int type() {
  MATCH(kwINT);
  return 0;
}

int opt_formals() {
  return 0;
}

int opt_var_decls() {
  return 0;
}

int opt_stmt_list() {
  while (tok_in_First(curr_tok, "stmt")) {
    stmt();
  }

  //CHK_TOK_IN_FOLLOW(curr_tok);
  return 0;
}

int stmt() {
  fn_call();
  return 0;
}

int fn_call() {
  MATCH(ID);
  MATCH(LPAREN);
  opt_expr_list();
  MATCH(RPAREN);
  MATCH(SEMI);
  return 0;
}

int opt_expr_list() {
  return 0;
}

/*******************************************************************************
 *                                                                             *
 *                            FIRST and FOLLOW sets                            *
 *                                                                             *
 *******************************************************************************/

typedef struct GrammarSet {
  char *_nterm;
  unsigned int _set;
} GrammarSet;

GrammarSet First[] = {
  {"fn_call",   SET(ID) },
  {"func_defn",   SET(kwINT) },
  {"opt_stmt_list",   SET(ID) },
  {"prog",   SET(kwINT) },
  {"stmt",   SET(ID) },
  {"type",   SET(kwINT) }
};

GrammarSet Follow[] = {
  {"fn_call",   (SET(ID) | SET(RBRACE)) },
  {"func_defn",   (SET(kwINT) | SET(EOF)) },
  {"opt_expr_list",   SET(RPAREN) },
  {"opt_formals",   SET(RPAREN) },
  {"opt_stmt_list",   SET(RBRACE) },
  {"opt_var_decls",   (SET(ID) | SET(RBRACE)) },
  {"prog",   SET(EOF) },
  {"stmt",   (SET(ID) | SET(RBRACE)) },
  {"type",   SET(ID) }  
};

int nsyms = sizeof(Follow)/sizeof(GrammarSet);

int tok_in_GrammarSet(Token tok, const char *nonterm, GrammarSet *gs) {
  int i;
  for (i = 0; i < nsyms; i++) {
    if (strcmp(nonterm, gs[i]._nterm) == 0) {
      return (SET(tok) & gs[i]._set);
    }
  }

  return 0;
}

int tok_in_First(int tok, const char *nonterm) {
  return tok_in_GrammarSet(tok, nonterm, First);
}

int tok_in_Follow(int tok, const char *nonterm) {
  return tok_in_GrammarSet(tok, nonterm, Follow);
}

/*******************************************************************************
 *                                                                             *
 *                                DRIVER INTERFACE                             *
 *                                                                             *
 *******************************************************************************/

/*
 * parse() : starts the parser.  Called by the external driver routine.  A return
 * value of 0 indicates normal execution; 1 indicates an error.
 */
int parse() {
  curr_tok = get_token();
  prog();

  return error_code;
}

