/*
 * File: parser-driver.c
 * Author: Saumya Debray
 * Purpose: The driver code for the G0 subset parser for the CSC 453 project
 */

#include <stdio.h>
#include "scanner.h"

extern int parse();

int main() {
  int error_code;
  error_code = parse();
  printf("ERROR CODE: %d\n", error_code);
  return 0;
}
