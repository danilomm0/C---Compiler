#!/usr/bin/env sh

OK_TESTS=`/bin/ls ../parser_tests/test[0-9]*`
ERR_TESTS=`/bin/ls ../parser_tests/err[0-9]*`

make 
for file in $OK_TESTS
do
    echo "INPUT: $file"
    ./compile < $file
done

for file in $ERR_TESTS
do
    echo "INPUT: $file"
    ./compile < $file
done
