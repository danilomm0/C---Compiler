/* identifiers of length > 1: mixed upper and lower-case letters */
aB
Abc
AbCd

