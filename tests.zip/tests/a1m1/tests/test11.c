/* identifiers: lower-case letters + digits + underscores */

a_1
a1_b
x1_y2_z3
x11_22y33_44z55__
a111__b222__333c
ab1234___5678cdef____90123ghijk456_____
ab1234___5678cdef____90123ghijk456_____789
