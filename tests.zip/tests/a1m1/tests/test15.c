/* identifiers that should not be recognized as keywords */
char
short
signed
unsigned
for
float
double
struct
volatile
