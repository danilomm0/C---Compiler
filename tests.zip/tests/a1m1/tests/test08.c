/* identifiers: upper-case letters + underscores */

A_
A_B
X_Y_Z
X_Y_Z_
A__B__C
AB___CDEF____GHIJK___________________LMN
AB___CDEF____GHIJK___________________LMN________________
