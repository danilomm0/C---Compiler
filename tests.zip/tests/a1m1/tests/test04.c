/* identifiers of length > 1: lower-case letters only */
ab
abc
abcd
abcdefghijklmnopqrstuvwxyz
