/* integer constants: 1 digit */
0
1
2
3
