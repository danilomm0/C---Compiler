/* integer constants: > 1 digit */
11
222
3333
44444
555555
