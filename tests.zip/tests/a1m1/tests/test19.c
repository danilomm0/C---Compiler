/* assignment */
=
 =
 = =
