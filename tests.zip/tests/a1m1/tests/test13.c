/* identifiers: mixed-case letters + digits + underscores */

aB_1
A1_b
x1_Y2_z3
X11_22Y33_44z55__
a111__B222__333c
aB1234___5678CdeF____90123GhIjk456_____
AbCDef1234___567gHIjk456_____789
