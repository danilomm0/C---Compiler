/* identifiers: lower-case letters + underscores */

a_
a_b
x_y_z
x_y_z_
a__b__c
ab___cdef____ghijk___________________lmn
ab___cdef____ghijk___________________lmn________________
