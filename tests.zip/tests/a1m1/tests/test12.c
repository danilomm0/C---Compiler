/* identifiers: upper-case letters + digits + underscores */

A_1
A1_B
X1_Y2_Z3
X11_22Y33_44Z55__
A111__B222__333C
AB1234___5678CDEF____90123GHIJK456_____
AB1234___5678CDEF____90123GHIJK456_____789
