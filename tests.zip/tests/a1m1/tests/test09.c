/* identifiers: low-case letters + digits */

a1
a11b
a11bc12cd123
a11bc222cde3333fg
