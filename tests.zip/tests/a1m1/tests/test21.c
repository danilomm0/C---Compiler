/* comparison operators */
==  ==  ==
!=  !=  !=
> > >
>= >= >=
< < <
<= <= <=
