/* identifiers of length > 1: upper-case letters only */
AB
ABC
ABCD
ABCDEFGHIJKLMNOPQRSTUVWXYZ
