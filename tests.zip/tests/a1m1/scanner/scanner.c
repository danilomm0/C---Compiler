#include <assert.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "scanner.h"

char buf[1024]; /* the buffer into which we read lexemes */
char *lexeme;
int linenum = 1;

int keyword_or_id(char *str)
{
  if (strcmp(str, "int") == 0)
  {
    return kwINT;
  }
  else if (strcmp(str, "if") == 0)
  {
    return kwIF;
  }
  else if (strcmp(str, "else") == 0)
  {
    return kwELSE;
  }
  else if (strcmp(str, "while") == 0)
  {
    return kwWHILE;
  }
  else if (strcmp(str, "return") == 0)
  {
    return kwRETURN;
  }
  else
  {
    return ID;
  }
}

int next_char()
{
  int ch = getchar();
  if (ch == '\n')
    linenum++;
  return ch;
}

void unget_next_char(char ch)
{
  if (ch == '\n')
    linenum--;
  putc(ch, stdin);
}

void ignorecomments()
{
  char ch, nextch;
  int state, done;

  do
  {
    done = 0;
    ch = next_char();

    /* skip any leading whitespace */
    while (ch != EOF && isspace(ch))
    {
      ch = next_char();
    }

    if (ch == EOF)
    {
      done = 1;
    }
    else if (ch == '/')
    {
      nextch = next_char();
      if (nextch == '*')
      { /* comment */
        /* the variable state emulates a DFA to recognize comments */
        state = 1;
        while (nextch != EOF && state != 3)
        {
          while ((nextch = next_char()) != '*')
          { /* skip */
          }

          assert(nextch == '*');
          state = 2;

          while ((nextch = next_char()) == '*')
          { /* skip */
          }

          if (nextch == '/')
          { /* found the end of the comment */
            state = 3;
          }
          else
          {
            state = 1;
          }
        }
      }
      else
      {
        unget_next_char(nextch);
        unget_next_char(ch);
        done = 1;
      }
    }
    else
    {
      unget_next_char(ch);
      done = 1;
    }
  } while (!done);
}

int get_token()
{
  char ch, nextch;
  int i;

  ignorecomments();

  while ((ch = next_char()) != EOF)
  {
    if (isalpha(ch))
    {
      /* keyword or identifier */
      i = 0;
      while (isalnum(ch) || ch == '_')
      {
        buf[i++] = ch;
        ch = next_char();
      }
      buf[i] = '\0';
      if (ch != EOF)
      {
        unget_next_char(ch);
      }

      lexeme = strdup(buf);
      return keyword_or_id(buf);
    }
    else if (isdigit(ch))
    {
      /* integer constant */
      i = 0;
      while (isdigit(ch))
      {
        buf[i++] = ch;
        ch = next_char();
      }
      buf[i] = '\0';
      if (ch != EOF)
      {
        unget_next_char(ch);
      }

      lexeme = strdup(buf);
      return INTCON;
    }
    else
    {
      switch (ch)
      {
      case '(':
        lexeme = "(";
        return LPAREN;
      case ')':
        lexeme = ")";
        return RPAREN;
      case '{':
        lexeme = "{";
        return LBRACE;
      case '}':
        lexeme = "}";
        return RBRACE;
      case ',':
        lexeme = ",";
        return COMMA;
      case ';':
        lexeme = ";";
        return SEMI;
      case '+':
        lexeme = "+";
        return opADD;
      case '-':
        lexeme = "-";
        return opSUB;
      case '*':
        lexeme = "*";
        return opMUL;
      case '/':
        lexeme = "/";
        return opDIV; /* comments already skipped */

      case '=':
        nextch = next_char();
        if (nextch == '=')
        {
          lexeme = "==";
          return opEQ;
        }
        else
        {
          unget_next_char(nextch);
          lexeme = "=";
          return opASSG;
        }
      case '!':
        nextch = next_char();
        if (nextch == '=')
        {
          lexeme = "!=";
          return opNE;
        }
        else
        {
          unget_next_char(nextch);
          lexeme = "!";
          return opNOT;
        }
      case '>':
        nextch = next_char();
        if (nextch == '=')
        {
          lexeme = ">=";
          return opGE;
        }
        else
        {
          unget_next_char(nextch);
          lexeme = ">";
          return opGT;
        }
      case '<':
        nextch = next_char();
        if (nextch == '=')
        {
          lexeme = "<=";
          return opLE;
        }
        else
        {
          unget_next_char(nextch);
          lexeme = "<";
          return opLT;
        }
      case '&':
        nextch = next_char();
        if (nextch == '&')
        {
          lexeme = "&&";
          return opAND;
        }
        else
        {
          fprintf(stderr, "Illegal character: %c\n", nextch);
          exit(1);
        }
      case '|':
        nextch = next_char();
        if (nextch == '|')
        {
          lexeme = "||";
          return opOR;
        }
        else
        {
          fprintf(stderr, "Illegal character: %c\n", nextch);
          exit(1);
        }
      default:
        fprintf(stderr, "Illegal character: %c\n", ch);
        exit(1);
      }
    }
  }

  lexeme = "";
  return EOF;
}
